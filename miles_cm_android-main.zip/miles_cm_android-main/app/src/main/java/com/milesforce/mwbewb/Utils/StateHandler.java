package com.milesforce.mwbewb.Utils;

public abstract class StateHandler {
    public static boolean IS_INCOMMING_EVENT = false;
    public static boolean IS_OUTGOING_EVENT = false;
    public static boolean IS_OUTGOING_EVENT_NEW=false;
    public static boolean IS_ONOUTGOING_CALL_EVENT=false;
    public static boolean IS_SUCCESS_CALL=false;

}