package com.milesforce.mwbewb.Utils;

public class CallTriggerEvent {

}
