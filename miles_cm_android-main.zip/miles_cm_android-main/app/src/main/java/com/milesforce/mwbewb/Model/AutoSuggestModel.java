package com.milesforce.mwbewb.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AutoSuggestModel {
    @SerializedName("corporates")
    @Expose
    private String corporates;


}
